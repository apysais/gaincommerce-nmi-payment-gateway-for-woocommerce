=== Gain Commerce NMI Payment Gateway for WooCommerce ===
Contributors: allan.casilum, gaincommerce
Tags: nmi, woocommerce, payment gateway, credit card, pci
Requires at least: 6.8
Tested up to: 6.9
Stable tag: 1.14.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires Plugins: woocommerce

PCI-compliant payment gateway integration between NMI and WooCommerce. Seamlessly accept e-commerce credit card payments through WooCommerce stores.

== Description ==

The <strong>Gain Commerce NMI Payment Gateway for WooCommerce</strong> is the premier free NMI plugin for secure, flexible credit card processing on your WooCommerce store. Developed for WooCommerce Blocks and HPOS compatibility. This plugin offers easy integration into WooCommerce to create a seamless customer checkout experience. Achieve top-tier security with full PCI-DSS Compliance through the NMI payment gateway, utilizing Collect.js for safe data tokenization that keeps sensitive card data off your server. 

Merchants gain essential features such as the Authorize Now and Capture Later flexibility, easy refunds, and voids, all managed from the full WooCommerce dashboard. Merchants can control which card types they accept, including Apple Pay, Google Pay, and PayPal. The plugin also supports advanced features such as Dynamic Descriptors and records AVS/CVV response codes. Streamline your transaction management with a reliable, feature-rich gateway plugin from Gain Commerce.

<strong>Free Plugin Version Includes</strong>
=
* <strong>Easy Integration</strong> into WooCommerce for a seamless customer checkout process. 
* <strong>Secure Payment Processing</strong> with full PCI-DSS Compliance via the NMI payment gateway.
* <strong>Credit Card Processing</strong> managed entirely by NMI with data tokenization through <a href="https://docs.nmi.com/docs/collectjs/" target="_blank">Collect.js</a>  
* <strong>Customer Vault</strong> for secure, remote customer card data storage.
* <strong>Manage Transactions</strong> from the WooCommerce dashboard.
* <strong>Customizable Settings</strong> in the WooCommerce admin.
* <strong>Control Card Types</strong> to accept or restrict all major credit card brands, as needed.
* <strong>Receipts</strong> from the WooCommerce dashboard through NMI.
* <strong>Refunds/Voids</strong> from the WooCommerce dashboard.
* <strong>AVS/CVV Response Codes</strong> recorded in order notes.
* <strong>Dynamic Descriptors</strong> variable descriptors for customer statements.
* <strong>Digital Wallets</strong> supported, including Apple Pay, Google Pay, and PayPal.
* <strong>Authorize Now and Capture Later</strong> flexibility for transactions occurring at a later date.
* <strong>Shipping Info</strong> sent to NMI transaction ledger.
* <strong>AVS/CVV Response Codes</strong> recorded in order notes.
* <strong>Logging</strong> to detect and fix errors or issues.

<strong>Premium Plugin Version Includes</strong>
=
* <strong>ACH Payments</strong> integrated electronic transfers through the ACH network.
* <strong>Stored Payments</strong> for card or ACH payments in the PCI-compliant Customer Vault.
* <strong>3D Secure 2 (3DS2)</strong> authentication to reduce fraud. PSD2/SCA Compliant.
* <strong>WooCommerce Subscriptions</strong>compatible to create and manage recurring payments.

<strong>Important Requirements:</strong>
=
* Active NMI account
* WooCommerce version 8.0 or higher.
* WooCommerce HPOS (High-Performance Order Storage)
* WordPress 6.8.*

<strong>Compatibility:</strong>
=
* WooCommerce 8.0+ (HPOS only)
* WooCommerce Subscription 8.6.0
* WordPress 6.8.*

== Source Code ==
The source code for the minified JS/CSS is available at: 
<a href="https://github.com/apysais/gaincommerce-nmi-payment-gateway-for-woocommerce/" target="_blank">Gain Commerce NMI Payment Gateway for WooCommerce</a>


Build instructions:
1. Clone the repository.
2. Run `npm install` to install dependencies.
3. Run `npm run build` to generate production assets.

== External Services ==
This plugin connects to the NMI payment gateway to process transactions.

* Service: <a href="https://www.nmi.com/" target="_blank">NMI Payment Gateway</a>
* Purpose: To process credit card payments securely.
* Data Sent: Card details (via tokenization), order details.
* <a href="https://www.nmi.com/legal/terms/" target="_blank">Terms of Service</a>
* <a href="https://www.nmi.com/legal/privacy/" target="_blank">Privacy Policy</a>

**When Data Is Sent:**  
Data is transmitted only when a customer submits payment information during checkout.

**Where Data Is Sent:**  
All sensitive data is sent directly to NMI’s secure servers. Your website does not store or process raw payment data.

The plugin loads the NMI Collect.js script for tokenization: 
=
* Script URL:</strong> <a href="https://docs.nmi.com/docs/collectjs" target="_blank">https://docs.nmi.com/docs/collectjs</a>
* Collect.js is a PCI-compliant JavaScript library provided by NMI to tokenize payment data in the browser before it reaches your server.

**Conditions:**  
Data is encrypted and tokenized using Collect.js. Only a single-use token is returned to your site for transaction processing.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/gaincommerce-nmi-payment-gateway-for-woocommerce` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Configure the plugin settings in WooCommerce > Settings > Payments > Gain Commerce NMI Payment Gateway.

== Frequently Asked Questions ==
= Is this plugin PCI Compliant? =
Yes. Utilizing NMI's Collect.js to tokenize payment data, sensitive information never touches merchant servers.

= Does this plugin require WooCommerce? =
Yes. WooCommerce 6.8 or higher must be installed and active.

= Does this plugin require a Network Merchants account? = 
Yes. An active NMI payment gateway account is required.  Contact <a href="https://www.alliedpayments.com" target="_blank">Allied Payments</a>, our preferred provider, to set up NMI payment gateway accounts.

= Is an SSL required? = 
Yes. A valid SSL certificate is required to protect customer credit card account information and to meet PCI-DSS compliance requirements. 

 = What information is passed to NMI? =
Payment account information is only transferred through tokenization to maintain absolute PCI Compliance. No sensitive payment information is sent over unsecured channels.

 = Does this plugin store customer information? =
No. This plugin does not store any customer credit card numbers or personal customer information.

 = For additional integration information and support =
Visit <a href="https://www.gaincommerce.com/support" target="_blank">gaincommerce.com/support</a>.

== Screenshots ==
1. WooCommerce Checkout Page layout
2. Gain Commerce/NMI settings page in WooCommerce
3. WooCommerce Order Notes displaying AVS, CVV, Confirmation, and Error codes from NMI.
4. Dynamic Descriptor settings in WooCommerce (when enabled in NMI)


== Changelog ==
= 1.14.5 =
* Support NMI Digital wallet payment, google and apple pay.

= 1.13.1 =
* Add WooCommerce Subscriptions support for automatic recurring payments. Requires WooCommerce Subscriptions plugin and Premium Add-on.
* Maintenance

= 1.12.0 =
* Fix checkout issue in loading NMI in legacy and block base.
* Fix UI fields in checkout page both in legacy and block base.
* Maintenance.

= 1.11.0 =
* Added support for 3D Secure (3DS) authentication when the Premium Add-on plugin is installed. The free plugin now enables 3DS for enhanced security, but requires the Premium plugin to activate this feature.

= 1.10.0 =
* Fix and replace deprecated reduced_stock_qty to wc_reduce_stock_levels
* Add ability for customers to store payment method for future transactions in card vault by choosing “Save Payment Method” during checkout. Available only in Premium Plugin
* Choose "Saved Payment Method" stores card account in secure PCI-Compliant environment. Customer can replace card in checkout process by choosing “Save Payment Method”.
* Test to latest WooCommerce version 10.4.3

= 1.8.1 =
* Test to latest WordPress 6.9 version.
* Test to latest WooCommerce 10.4.2
* Add Description for premium plugin in readme file.

= 1.8.0 =
* Add Shipping Fields from WooCommerce order to NMI merchants.
* Ability to enable Dynamic Descriptor and pass descriptor data.
* Add AVS/CVV notes in order.
* Add additional order notes as Response code and NMI payment status.

= 1.7.6 =
* Integrate restrict card type in block checkout
* Integrate restrict card type in legacy checkout
* Integrate CollectJS into WC checkout blocks
* Integrate WC blocks
* Add CollectJS to legacy checkout
* WooCommerce Legacy checkout work on NMI
* Add Auth Feature and when changed to order processing or complete then capture
* Add Gateway Class
* Add Logger Class
* Add API class for NMI
* Add API Factory
* Add API Credit Card Sale
* Add API Refund
* Add API Void
* Add API Auth, Capture and Auth + Capture

= 1.0.0 =
* Initial release

== Upgrade Notice ==
= 1.0.0 =
Initial release of Gain Commerce NMI Payment Gateway for WooCommerce plugin.

= Additional Information Required =
Visit our support page at <a href="https://www.gaincommerce.com/support" target="_blank">Gain Commerce</a>